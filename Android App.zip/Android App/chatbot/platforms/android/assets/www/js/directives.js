angular.module('app.directives', [])

.directive('messenger', function() {
    return {
        templateUrl: function() {
            return 'templates/mainpage.html'
        },
        controller: 'messengerCtrl',
        controllerAs: 'vm',
        restrict: 'E',
        scope: {},
            link: function($scope, $element){
                var $parent = $element.parents('.collapse:first');
                if($parent && $parent.length>0) {
                    $element.on('click.click-here', 'a[data-toggle]', function () {
                        //$parent.collapse('hide');
                    })
                }
            }
    };
})
.directive('displayMsg', function(){
    return {
        strict: 'A',
        link: function($scope, $element, attr){
            var path = attr.displayMsg || attr.dataDisplayMsg;
            if(path)
                $element.html($scope.$eval(path));
        }
    }
})
.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
});
