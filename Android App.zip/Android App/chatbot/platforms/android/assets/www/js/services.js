angular.module('app.services', [])

.factory('BlankFactory', [function(){

}])

.service('dialogService', ['$http', DialogService]);
