(function(angular) {
    'use strict';

    var messenger = angular.module('app.messenger', []);

    // messenger.config(['$routeProvider', function($routeProvider){
    //     $routeProvider.when()
    // }]);

    messenger.controller('dialogController', ['$scope', 'dialogService', '$interval', '$timeout', '$rootScope', '$q',
        function($scope, dialogService, $interval, $timeout, $rootScope, $q) {

            var defaultUser = { left: true };
            var defaultBot = { left: false };

            $scope.history = [];
            // $scope.input = '';

            // $scope.payload = {};

            // $scope.response = {};

            $scope.conversation = {};

            function captureHistory (option, text, html){
                if(!text) return;
                var msg = angular.extend({}, option, { text: text, html: html });
                msg.time = moment();
                msg.displayTime = msg.time.fromNow();
                $scope.history.push(msg);
            }

            $interval(function(){
                for(var i=0;$scope.history && i<$scope.history.length;i++)
                {
                    var msg = $scope.history[i];
                    if(msg.time)
                        msg.displayTime = msg.time.fromNow();
                }
            }, 1000 * 60);

            this.doConversation = function() {
                var msg = $scope.$eval('conversation.input.text');
                captureHistory.call(this, defaultUser, msg);

                dialogService.message($scope.conversation)
                    .then(function(response) {
                        var conversation = response.data.conversation;

                        var events = conversation.output.events;

                        var handleEvent = function(event){
                            if(!event.sent)
                            {
                                var chains = [];
                                $rootScope.$broadcast('messenger-' + (event.name || '').toLowerCase(), event.args, conversation, chains);
                                event.sent = true;
                                if(chains && chains.length > 0)
                                    return $q.all(chains);
                                else
                                {
                                    var dfd = $q.defer();
                                    $timeout(function(){ dfd.resolve(true); }, 50);
                                    return dfd.promise;
                                }
                            }
                        };

                        var begin = null;

                        var j=0;
                        for(j=0; events && j<events.length;j++){
                            var event = events[j];
                            if(!begin)
                            {
                                begin = handleEvent.call(this, event);
                            }
                            else {
                                begin = begin.then(handleEvent.bind(this, event));
                            }
                        }

                        var oncomplete = function(){
                            var texts = conversation.output.text;
                            var html = conversation.output.html;
                            if(html)
                                captureHistory(defaultBot, texts.join('\n'), html);

                            return angular.extend($scope.conversation, conversation);
                        }

                        if(begin)
                        {
                            return begin.then(oncomplete);
                        }

                        return oncomplete();
                    })
                    .catch(function(ex) {
                        console.log(ex);
                    })
                    .finally(function() {
                        $scope.$eval('conversation.input.text = ""');
                        $timeout($scope.$apply.bind($scope), 200);
                    });

            };

            this.doConversation();
        }
    ]);

    messenger.directive('messenger', function() {
        return {
            templateUrl: function() {
                return 'templates/mainpage.html'
            },
            controller: 'dialogController',
            controllerAs: 'vm',
            restrict: 'E',
            scope: {}
        };
    });

    messenger.directive('displayMsg', function(){
        return {
            strict: 'A',
            link: function($scope, $element, attr){
                var path = attr.displayMsg || attr.dataDisplayMsg;
                if(path)
                    $element.html($scope.$eval(path));
            }
        }
    })

    function DialogService($http) {
        this.$http = $http;
    }

    DialogService.prototype.message = function(payload) {
        return this.$http.post('api/interactions/conversation', payload);
    };

    messenger.service('dialogService', ['$http', DialogService]);

})(angular);
