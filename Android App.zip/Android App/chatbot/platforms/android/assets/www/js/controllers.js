angular.module('app.controllers', [])

.controller('menuCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('messengerCtrl', ['$scope', 'dialogService', '$interval', '$timeout', '$rootScope', '$q','$ionicPopup','$ionicScrollDelegate','$rootScope', '$location',
    function($scope, dialogService, $interval, $timeout, $rootScope, $q,$ionicPopup,$ionicScrollDelegate,$rootScope, $location) {

        //============================== doConversation =================================================
        var defaultUser = { left: true };
        var defaultBot = { left: false };

        $scope.history = [];


        // $scope.input = '';

        // $scope.payload = {};

        // $scope.response = {};

        $scope.conversation = {};

        function captureHistory (option, text, html){
            if(!text) return;
            var msg = angular.extend({}, option, { text: text, html: html });
            msg.time = moment();
            msg.displayTime = msg.time.fromNow();
            $scope.history.push(msg);
        }

        $interval(function(){
            for(var i=0;$scope.history && i<$scope.history.length;i++)
            {
                var msg = $scope.history[i];
                if(msg.time)
                    msg.displayTime = msg.time.fromNow();
            }
        }, 1000 * 60);

        $scope.doConversation = function() {
            var msg = $scope.$eval('conversation.input.text');
            captureHistory.call(this, defaultUser, msg);

            dialogService.message($scope.conversation)
                .then(function(response) {
                    var conversation = response.data.conversation;

                    var events = conversation.output.events;

                    var handleEvent = function(event){
                        if(!event.sent)
                        {
                            var chains = [];
                            $rootScope.$broadcast('messenger-' + (event.name || '').toLowerCase(), event.args, conversation, chains);
                            event.sent = true;
                            if(chains && chains.length > 0)
                                return $q.all(chains);
                            else
                            {
                                var dfd = $q.defer();
                                $timeout(function(){ dfd.resolve(true); }, 50);
                                return dfd.promise;
                            }
                        }
                    };

                    var begin = null;

                    var j=0;
                    for(j=0; events && j<events.length;j++){
                        var event = events[j];
                        if(!begin)
                        {
                            begin = handleEvent.call(this, event);
                        }
                        else {
                            begin = begin.then(handleEvent.bind(this, event));
                        }
                    }

                    var oncomplete = function(){
                        var texts = conversation.output.text;
                        var html = conversation.output.html;
                        if(html){
                          captureHistory(defaultBot, texts.join('\n'), html);
                           $ionicScrollDelegate.scrollBottom();
                        }

                        return angular.extend($scope.conversation, conversation);
                    }

                    if(begin)
                    {
                        return begin.then(oncomplete);
                    }

                    return oncomplete();
                })
                .catch(function(ex) {
                    console.log(ex);
                })
                .finally(function() {
                    $scope.$eval('conversation.input.text = ""');
                    $timeout($scope.$apply.bind($scope), 200);
                });


        };

        $scope.doConversation();
        //============================== End doConversation =================================================
        //============================== Popup Exit App ====================================================
        $scope.showOptionSetting = function() {
            var myPopup = $ionicPopup.show({
               template: 'Do you want to logout?',
               scope: $scope,
               title:'Logout',
               buttons: [
                  { text: 'Yes',
                    type:'button-stable',
                    onTap:function(e){
                          navigator.app.exitApp();
                          myPopup.close();
                     }
                  },
                  { text: 'No',
                    type:'button-stable',
                    onTap:function(e){
                        myPopup.close();
                     }

                  },
               ]
            });

            myPopup.then(function(res) {
               console.log('Tapped!', res);
            });
         };
         //============================== End  Popup Exit App====================================================
         //============================== Transfer Funds ====================================================
         var fromAccounts = [
             {id: 1, fundName: 'US Growth Fund', currentValue: 48222},
             {id: 2, fundName: 'UK Growth Fund', currentValue: 58123},
             {id: 3, fundName: 'China Growth Fund', currentValue: 81042},
             {id: 4, fundName: 'India Growth Fund', currentValue: 41042}
         ];

         var toAccounts = [
             {id: 1, fundName: 'Global Equity Fund', currentValue: 100222},
             {id: 2, fundName: 'US Growth Fund', currentValue: 48222},
             {id: 3, fundName: 'UK Growth Fund', currentValue: 58123},
             {id: 4, fundName: 'China Growth Fund', currentValue: 81042},
             {id: 5, fundName: 'India Growth Fund', currentValue: 41042}
         ];

         function buildDisplayName(){
             var arg = $.makeArray(arguments);

             for(var i=0;arg && i<arg.length;i++)
             {
                 var item = arg[i];
                 if(item && item.fundName)
                     item.name = (i+1).toString() + ') ' + item.fundName;
             }

             return arg;
         }


         buildDisplayName.apply(this, fromAccounts);
         buildDisplayName.apply(this, toAccounts);

         $scope.FromAccounts = fromAccounts;
         $scope.ToAccounts = toAccounts;

         $scope.SelectedFromAccount = '';
         $scope.SelectedToAccount = '';


         //watch for event of collect list of data to display in the message
         $scope.$on('messenger-list', function(e, args, conversation){
             var html = conversation.output.html;

             if(html && /\{\w*\}/.test(html)) {
                 var match = /\{(\w*)\}/.exec(html);
                 var path = match[1];
                 var found = match[0];
                 var value = $scope.$eval(path);
                 if(value == null) return;

                 if ($.type(value) == 'array') {
                     var arr = [];
                     for (var j = 0; value && j < value.length; j++) {
                         var _v = value[j];
                         switch ($.type(_v)) {
                             case 'string':
                                 arr.push(_v);
                                 break;
                             case 'object':
                                 if (_v.name)
                                     arr.push(_v.name);

                                 break;
                         }
                     }
                     value = arr.join('<br/>');
                 }

                 conversation.output.html = html.replace(found, value || '');
             }
         });

         //watch for event to select and fill data
         $scope.$on('messenger-update', function(e, args, conversation){
             if(args && args.length > 1 && conversation && convresation.context)
             {
                 var path = args[0], exp = args[1];
                 var getConversationVar = $parse(exp);
                 $scope[path] = getConversationVar(conversation.context);
                 $timeout(function(){
                     $scope.$apply();
                 }, 500);
             }
         })
        //==============================End Transfer Funds ====================================================
        function onRouteComplete($scope, current) {
            var title = current.$$route.title;

            angular.element(document)
                .trigger('locationChange', jQuery)
                .attr('title','Infinity Mutual' + (title?(' | ' + title):''));

            if(dfd) {
                dfd.resolve(
                    {
                        url: $location.absUrl(),
                        path: $location.path()
                    }
                    );
                dfd = null;
            }
        }

        $rootScope.$on('$routeChangeSuccess', function (e, current, previous) {
            $scope.title = current.$$route.title;
            $timeout(onRouteComplete.bind(this, $scope, current), 200);
        });

        var dfd = null;

        $scope.$on('messenger-navigate', function (e, args, conversation, chain) {
            var path = args && args.length>0?args[0]:'';
            if(path)
            {
                dfd = $q.defer();
                $location.path('/' + path);
                chain.push(dfd.promise.then(function(conversation, arg){
                    if(!arg) arguments;

                    var url = arg.url;
                    var path = arg.path;

                    var clickHeres = {
                        '/change-address': '<a style="pointer-events: all; cursor: pointer;" data-toggle="modal" data-target=".change-address-detail-modal">Click Here</a>',
                    '/transfer-fund': '<a style="pointer-events: all; cursor: pointer;" data-toggle="modal" data-target=".transfer-fund-detail-modal">Click Here</a>'
                };
                    conversation.output.html = (conversation.output.html || '').formatWithContext({
                        URL: '<a style="pointer-events: all; cursor: pointer;color:blue" ng-click="openChangeAddress()" >Click Here</a>' //clickHeres[path]
                    });

                    return arguments;
                }.bind(this, conversation)));

                $timeout(function(){
                    if(!dfd)
                        return;
                    dfd.resolve(
                        {
                            url: $location.absUrl(),
                            path: $location.path()
                        }
                        );
                    dfd = null;
                }, 2000);
            }
        });
        $scope.openChangeAddress = function()
        {
          window.open('https://insurancebotdemo.mybluemix.net/#/change-address','_bank');
          alert(1);
        };
        $scope.goTourl = function(path) {
          $location.path(path);
        };
    }
]);
function formatWithContext($scope){
    var html = this;
    var pattern = /\{(\w*)\}/ig;
    var match = null;
    var lastIndex = 0;
    var result = '';

    while((match = pattern.exec(html))!==null)
    {
        var path = match[1];
        var found = match[0];
        var value = $scope.$eval?$scope.$eval(path):$scope[path];

        if (value && $.type(value) == 'array') {
            var arr = [];
            for (var j = 0; value && j < value.length; j++) {
                var _v = value[j];
                switch ($.type(_v)) {
                    case 'string':
                        arr.push(_v);
                        break;
                    case 'object':
                        if (_v.name)
                            arr.push(_v.name);

                        break;
                }
            }
            value = arr.join('<br/>');
        }

        if (value == null) continue;

        var index = match.index;
        result += html.substring(lastIndex, index);
        result += value;

        lastIndex = index + found.length;
    }

    result += html.substring(lastIndex);

    return result;
  }
String.prototype.formatWithContext = formatWithContext;
function DialogService($http) {
    this.$http = $http;
}

DialogService.prototype.message = function(payload) {
      return this.$http.post('http://insurancebotdemo.mybluemix.net/api/interactions/conversation', payload);
  };
